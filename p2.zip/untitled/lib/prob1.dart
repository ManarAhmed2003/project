main() {
var z = Zebra();
z.set_value('zebra',5);
z.display();
z.place('Africa');
var d = Dolphin();
d.set_value('dolphin',2);
d.display();
d.place('water');
}
abstract class Animal {
 String name = '';
 int age = 0;
 void set_value (String n,int a){
  name = n;
  age = a;
 }
 void display();
 void place ();
}
class Zebra extends Animal {
  void display() {
  }
  void place() {
  }
}
class Dolphin extends Animal {
  void display() {
  }

  @override
  void place() {

  }

}

