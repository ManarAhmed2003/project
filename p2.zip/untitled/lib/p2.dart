import 'dart:ffi';

class Bank {
  late String _name;
  late String _address;
  var _accountType;
  late double _balance;
  //Constructor of the class Bank:
  Bank(){
    //Initializing values:
    _name= " ";
    _address= " ";
    _accountType= '';
    _balance=0;
  }
  //Method to open the account:
  void openAccount(){
    _name = "Ahmed";
    print('Enter your full name : $_name ');
    _address = "Cairo";
    print('Enter your address : $_address ');
    _accountType = 'S';
    print('What type of account you want ? $_accountType ');
    print('to open saving (S) or current (C) :$_accountType ');
    _balance=8000;
    print('Enter how much money you want to deposit : $_balance');
    print('Account created successfully');
  }
  //Method to deposit the account:
void depositMoney(){
    int amount;
    amount=9500;
    print('Enter how much money you want to deposit :$amount');
    _balance+=amount;
    print('Available Balance : $_balance');
}
//Method to display the account:
void displayAccount(){
    print('Name : $_name');
    print('Address : $_address');
    print('Type : $_accountType');
    print('Balance : $_balance');
}
//Method to withdraw the account:
void withdrawMoney(){
    double amount;
    amount=3200;
    print('Enter how much money you want to withdraw : $amount');
    _balance -= amount;
    print('Availlable Balance : $_balance');
}

}
//Main Method:
main(){
  int choice;
  //create object of the class Bank (customer):
  Bank customer = new Bank();
  print(' Open Account ');
  //calling openAccount() method :
  customer.openAccount();
  print('-----------------------------------');
  print(' Deposit Account ');
  //calling depositMoney() method :
  customer.depositMoney();
  print('-----------------------------------');
  print(' Wihdraw Money ');
  //calling withdrawMoney() method :
  customer.withdrawMoney();
  print('-----------------------------------');
  print(' Display Account ');
  //calling displayAccount() method :
  customer.displayAccount();
  print('-----------------------------------');


}