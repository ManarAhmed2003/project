import 'package:flutter/material.dart';
void main(){
  runApp(MainApp());
}
class MainApp extends StatelessWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home:Home() ,
    );
  }
}
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        centerTitle: true,
        shadowColor: Colors.red,
        title: Text(
          'Flutter circle \" Cat Reloaded\"', style: TextStyle(fontSize: 22),),
        leading: Icon(Icons.arrow_back, color: Colors.red, size: 35,),
        actions: [
          Icon(Icons.notifications, color: Colors.red, size: 35,)
        ],
      ),
    body: Column(
      children: const [
        SizedBox(
          child: Image(image: NetworkImage("https://blogger.googleusercontent.com/img/a/AVvXsEiGmYRXtvOGnKhXcP7wQ6QQoiHVEC6SvoNNQmr69esydYPTYQU67rA6l9MZwoXKYtPmUCcP53xAN__VGISUbcwlmQAGqpV6xxKWNGU2odIGatYKHUWuFQCZ7hdeGREn5apDJDS1-JqCBmiCGpcGZmdbEcHX-FsqkWDimlfcwehW5F14_1Rg6HgwRCPftA=w400-h400")),
          width: 700,
          height: 500,
        ),
        Text('Members',style:TextStyle(fontSize:50, fontWeight: FontWeight.bold ,)),
        Text('1- mohammed El-Helbawy',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,)),
        Text('2- Mohammed Shalaby',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,)),
        Text('3- Ebrahim Shaaban',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,)),
    ],


    /*  body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center,
     children: [SizedBox(height: 50,child:Text('Members',style:TextStyle(fontSize:50, fontWeight: FontWeight.bold ,))),
      SizedBox(height: 50,child:Text('',style:TextStyle(fontSize:20, fontWeight: FontWeight.bold ,))),
       SizedBox(height: 50,child:Text('1 mohammed El-Helbawy',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,))),
       SizedBox(height: 50,child:Text('2 Mohammed Shalaby',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,))),
       SizedBox(height: 50,child:Text('3 Ebrahim Shaaban',style:TextStyle(fontSize:25, fontWeight: FontWeight.bold ,))),*/


       //Text('1     mohammed El-Helbawy',style:TextStyle(fontSize: 25,fontWeight: FontWeight.bold ,)),
     // Text('2   Mohammed Shalaby',style:TextStyle(fontSize: 25,fontWeight: FontWeight.bold ,)),
      //Text('3   Ebrahim Shaaban',style:TextStyle(fontSize: 25,fontWeight: FontWeight.bold ,)),


      //child: Text('Members',
       // style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),),
      ),
    )
   ;
  }
}

